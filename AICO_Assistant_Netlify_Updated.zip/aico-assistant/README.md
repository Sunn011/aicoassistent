# 🤖 AICO Assistant

### AI-Powered Daily Operations & Team Coordination Platform

AICO Assistant is a self-built intelligent workspace designed to help startups and teams manage client requests, automatically organize work, assign tasks, monitor progress, handle blockers, and keep everyone updated from one place.

The application is designed and developed as an independent project and is deployed through **Netlify**.

---

## ✨ What AICO Assistant Does

AICO Assistant brings client communication and team execution into one intelligent workflow.

### Core workflow

1. 📩 A client sends a request.
2. 🧠 AICO analyzes the request and breaks the work into actionable tasks.
3. 👥 Tasks are assigned to suitable team members using skills, seniority and workload.
4. 📊 Team members can track their assigned work and update progress.
5. 🔔 Notifications keep the team informed about important events.
6. 🚨 Blockers can be raised and escalated when attention is required.
7. ✅ When the project is completed, AICO prepares a completion summary for the client.

---

# 🏗️ System Architecture

```text
                         ┌──────────────────────┐
                         │       CLIENT         │
                         │  Request / Email     │
                         └──────────┬───────────┘
                                    │
                                    ▼
                    ┌──────────────────────────────┐
                    │       AICO ASSISTANT         │
                    │     Intelligent Workspace    │
                    └──────────────┬───────────────┘
                                   │
              ┌────────────────────┼────────────────────┐
              │                    │                    │
              ▼                    ▼                    ▼
      ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
      │ Request      │     │ AI Task      │     │ Team &       │
      │ Processing   │     │ Planner      │     │ Workload     │
      └──────┬───────┘     └──────┬───────┘     │ Analysis     │
             │                    │              └──────┬───────┘
             └────────────────────┼────────────────────┘
                                  ▼
                         ┌─────────────────┐
                         │ Task Assignment │
                         │ & Prioritizing  │
                         └────────┬────────┘
                                  │
                                  ▼
                    ┌──────────────────────────┐
                    │       TEAM WORKSPACE     │
                    │                          │
                    │ • Tasks                  │
                    │ • Progress               │
                    │ • Notifications          │
                    │ • Blockers               │
                    │ • Activity               │
                    └────────────┬─────────────┘
                                 │
                 ┌───────────────┼────────────────┐
                 │               │                │
                 ▼               ▼                ▼
          ┌────────────┐  ┌────────────┐  ┌──────────────┐
          │ Progress & │  │ Blocker &  │  │ Completion  │
          │ Status     │  │ Escalation │  │ Summary     │
          └────────────┘  └────────────┘  └──────┬───────┘
                                                  │
                                                  ▼
                                         ┌────────────────┐
                                         │     CLIENT     │
                                         │ Final Update   │
                                         └────────────────┘

                 ┌───────────────────────────────┐
                 │       NETLIFY DEPLOYMENT      │
                 │  AICO Assistant Application   │
                 └───────────────────────────────┘
```

### Architecture layers

| Layer | Responsibility |
|---|---|
| 🎨 AICO Interface | Dashboard, employee views, project information and interactions |
| 📩 Request Processing | Receives and validates client requests |
| 🧠 AI Task Planner | Converts requests into structured tasks |
| 👥 Assignment Engine | Matches tasks with team skills, seniority and workload |
| 📊 Work Tracking | Tracks task status, progress and activity |
| 🚨 Escalation System | Handles blockers, reminders and critical issues |
| 🔔 Notification System | Displays important updates to the appropriate people |
| 📤 Client Communication | Provides acknowledgements and completion summaries |
| ☁️ Netlify | Hosts and publishes the AICO Assistant application |

---

# 🧠 Intelligent Task Assignment

AICO evaluates available team members for each task using three main factors:

- **Skill match** — how closely the person's skills match the task.
- **Seniority fit** — whether the person's experience level is appropriate.
- **Current workload** — how much work is already assigned to the person.

The assignment process considers tasks one at a time so that newly assigned work is reflected when selecting the next person.

Tasks can also receive priorities such as:

- 🔴 Urgent
- 🟠 High
- 🟢 Normal

Deadlines and client wording can be used to determine priority.

---

# 📊 Team Workspace

Each team member can work with their assigned tasks and monitor project activity.

The workspace can include:

- Current tasks
- Task progress
- Pending work
- Completed work
- Project deadlines
- Notifications
- Blockers
- Activity history
- Assignment information

This gives the team a single place to understand what needs to be done and what requires attention.

---

# 🚨 Blocker & Escalation Flow

When a team member encounters a problem:

```text
Employee identifies blocker
          ↓
      Raise blocker
          ↓
   AICO records issue
          ↓
   ┌──────┴──────┐
   │             │
 Normal       Critical
   │             │
   ▼             ▼
Team Lead    Team Lead +
notification   Admin alert
   │             │
   └──────┬──────┘
          ▼
   Blocker resolved
          ↓
      Work continues
```

This helps reduce delays and makes important operational risks visible.

---

# 📩 Client Request Flow

```text
Client Request
      ↓
AICO Request Processing
      ↓
AI / Rule-Based Task Planning
      ↓
Task Creation
      ↓
Skill + Seniority + Workload Analysis
      ↓
Task Assignment
      ↓
Team Execution
      ↓
Progress Updates
      ↓
Completion
      ↓
Client Summary
```

---

# 🛠️ Technology Used

- **HTML / CSS / JavaScript** — application interface
- **Node.js** — application runtime
- **AI task-planning logic** — intelligent request-to-task conversion
- **SMTP / IMAP integrations** — client and team communication workflows
- **Server-Sent Events (SSE)** — live application updates
- **JSON data storage** — lightweight project and activity storage
- **Netlify** — application deployment and hosting

---

# 📁 Project Structure

```text
AICO-Assistant/
│
├── public/
│   └── index.html              # AICO application interface
│
├── src/
│   ├── config.js               # Application configuration
│   ├── seed.js                 # Initial team/project data
│   ├── store.js                # Data storage
│   ├── planner.js              # Intelligent task planning
│   ├── assign.js               # Task assignment logic
│   ├── service.js              # Application workflows
│   ├── mailer.js               # Email communication
│   └── inbox.js                # Incoming message processing
│
├── server.js                   # Application entry point
├── package.json                # Project configuration
├── .env.example                # Configuration template
└── README.md                   # Project documentation
```

---

# 🚀 Run the Project Locally

### Requirements

- Node.js 18+
- npm

### Installation

```bash
npm install
```

Create your environment configuration:

```bash
cp .env.example .env
```

Start the application:

```bash
npm start
```

For development:

```bash
npm run dev
```

Run tests:

```bash
npm test
```

---

# ☁️ Deployment

AICO Assistant is deployed as an independently developed application on **Netlify**.

The production application is available at:

**https://aicoassistent.netlify.app**

For a new deployment, connect the project repository to Netlify and configure the required environment variables from `.env.example`.

### Production flow

```text
GitHub Repository
       ↓
     Netlify
       ↓
AICO Assistant
       ↓
Public Application
```

---

# 🔐 Configuration

The `.env.example` file contains the configuration names used by the application.

Important values can include:

| Variable | Purpose |
|---|---|
| `COMPANY_NAME` | Company/workspace name |
| `DELIVERY_EMAIL` | Client delivery address |
| `TEAM_LEAD_NAME` | Team lead name |
| `TEAM_LEAD_EMAIL` | Team lead email |
| `ADMIN_EMAIL` | Administrator email |
| `SMTP_HOST` | Email service host |
| `SMTP_PORT` | Email service port |
| `SMTP_USER` | Email account |
| `SMTP_PASS` | Email account credential |
| `SMTP_FROM` | Sender address |
| `IMAP_HOST` | Incoming mailbox host |
| `IMAP_USER` | Incoming mailbox account |
| `IMAP_PASS` | Incoming mailbox credential |
| `ANTHROPIC_API_KEY` | Optional AI planning integration |

Never commit real credentials or API keys to GitHub.

---

# 🔌 Application Routes

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/health` | Application health check |
| GET | `/api/state` | Current projects, employees, tasks and activity |
| GET | `/api/events` | Live notifications and state updates |
| POST | `/api/mails` | Create a project from a client request |
| POST | `/api/tasks/:id/start` | Start a task |
| POST | `/api/tasks/:id/progress` | Update task progress |
| POST | `/api/tasks/:id/complete` | Complete a task |
| POST | `/api/tasks/:id/blocker` | Raise a blocker |
| POST | `/api/tasks/:id/resolve` | Resolve a blocker |
| POST | `/api/tasks/:id/reassign` | Reassign a task |
| POST | `/api/tasks/:id/nudge` | Send a task reminder |
| POST | `/api/notifications/read` | Mark notifications as read |
| POST | `/api/reset` | Restore demonstration data |

---

# 🎯 Project Objective

The objective of AICO Assistant is to reduce the manual coordination required when a startup receives client work.

Instead of relying on scattered emails, messages and spreadsheets, AICO creates a connected workflow where requests become tasks, tasks become assignments, progress becomes visible, blockers become actionable alerts, and completed work can be communicated back to the client.

---

# 🌟 Key Highlights

- 🤖 AI-assisted task planning
- 👥 Intelligent team assignment
- 📊 Real-time work tracking
- 🔔 Live notifications
- 🚨 Blocker detection and escalation
- 📩 Client communication workflow
- 📈 Workload-aware task allocation
- ⏱️ Deadline and priority tracking
- ☁️ Netlify deployment
- 🧩 Fully self-built project architecture

---

# 👨‍💻 Project

**AICO Assistant**

> An intelligent workspace that turns client requests into organized, trackable team execution.

Built as an independent AI-powered application and deployed on Netlify.
